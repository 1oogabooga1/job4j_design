package ru.job4j.oop;

public class Wolf {
    public void eat(Girl girl) {
    }

    public void tryEat(Ball ball) {
        ball.tryRun(false);
    }
}
