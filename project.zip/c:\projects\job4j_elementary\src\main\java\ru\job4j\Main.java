package ru.job4j;

public class Main {
    public static void main(String[] args) {
        System.out.println("чао какао ");
    }
}