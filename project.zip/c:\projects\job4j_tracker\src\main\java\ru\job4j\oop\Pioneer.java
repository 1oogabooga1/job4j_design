package ru.job4j.oop;

public class Pioneer {
    public void kill(Wolf wolf) {

    }
}
