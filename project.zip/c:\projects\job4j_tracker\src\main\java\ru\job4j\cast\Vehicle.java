package ru.job4j.cast;

public interface Vehicle {
    void move();
}
