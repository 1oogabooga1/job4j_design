package ru.job4j.stream;

public record Tuple(String name, double score) {
}
