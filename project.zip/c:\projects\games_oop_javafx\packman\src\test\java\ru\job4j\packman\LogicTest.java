package ru.job4j.packman;

public class LogicTest {
}