package ru.job4j.polymorph;

public interface Fuel {
    void refill();
}
