package ru.job4j.record;

public record PersonRecord(String name, int age) {
}
