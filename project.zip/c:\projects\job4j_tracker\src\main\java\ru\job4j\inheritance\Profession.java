package ru.job4j.inheritance;

public class Profession {
    private boolean degree;

    public Profession(int experience, boolean degree) {
        this.degree = degree;
    }
}
