package ru.job4j.stream;

public enum Suit {
    Diamonds, Hearts, Spades, Clubs
}

