package ru.job4j;

public class Multiple {
    public static void main(String[] args) {
        System.out.println("1*1=1");
        System.out.println("1*2=2");
        System.out.println("1*3=3");
        System.out.println("1*4=4");
        System.out.println("1*5=5");
        System.out.println("1*6=6");
        System.out.println("1*7=7");
        System.out.println("1+8=8");
        System.out.println("1*9=9");

    }
}
