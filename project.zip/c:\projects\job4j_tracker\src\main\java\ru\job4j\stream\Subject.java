package ru.job4j.stream;

public record Subject(String name, int score) {
}
