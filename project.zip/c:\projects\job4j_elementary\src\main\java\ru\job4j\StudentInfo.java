package ru.job4j;

public class StudentInfo {
    public static void main(String[] args) {
        System.out.println("Dmitrii Dobrydin");
        System.out.println("10.11.2005");
    }
}
