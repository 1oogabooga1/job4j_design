package ru.job4j.queue;

public enum Position {
    DIRECTOR,
    DEPUTY_DIRECTOR,
    DEPARTMENT_HEAD,
    MANAGER
}
